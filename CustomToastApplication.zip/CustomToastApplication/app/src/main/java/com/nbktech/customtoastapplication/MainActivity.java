package com.nbktech.customtoastapplication;

import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button customtoast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        customtoast = (Button)findViewById(R.id.custom_toast_btn);

        customtoast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                View view1 = View.inflate(MainActivity.this,R.layout.custom_toast_item,null);

                ImageView image_toast = (ImageView)view1.findViewById(R.id.image_toast);
                TextView text_toast = (TextView)view1.findViewById(R.id.name_toast);

                text_toast.setText("Custom Toast Message");

                Toast toast = new Toast(getApplicationContext());
                //toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                toast.setDuration(Toast.LENGTH_LONG);
                toast.setView(view1);
                toast.show();
            }
        });
    }
}
